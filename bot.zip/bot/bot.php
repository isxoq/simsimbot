<?php
$params = require('./params.php');
require('./database.php');
require('./functions.php');


define('API_KEY', $params['botToken']);
define('ADMIN', $params['admin_id']);

function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($datas));
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$contact = $message->contact;
$location = $message->location;
//Callback
$c = $update->callback_query;
$cdata = $update->callback_query->data;
$cchat_id = $update->callback_query->message->chat->id;
$cqid = $update->callback_query->id;
$cmessage_id = $update->callback_query->message->message_id;
$cfrom_id = $update->callback_query->from->id;
//Callback

$text = $update->message->text;
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
//$panel = file_get_contents("panel.txt");
$name = $message->from->first_name;
$lastname = $message->from->last_name;
$username = $message->from->username;
$from_id = $message->from->id;

function answerCallback(){
    global $cqid;
    bot('answerCallbackQuery', [
        'callback_query_id' => $cqid,
    ]);
}

if ($text == t('home')){
    home($chat_id);
}
if ($text == t('verify')){
    bot('sendMessage',[
        'text'=>t('process_save'),
        'chat_id'=>$chat_id
    ]);
    saveOrder($from_id);
    sendNotification($chat_id,$from_id,ADMIN);
    cancelOrder($from_id);
    bot('sendMessage',[
        'text'=>t('order_accepted'),
        'chat_id'=>$chat_id,
        'parse_mode'=>"HTML",
        'reply_markup'=>json_encode([
            'keyboard'=>[
                [['text'=>t('home')]]
            ],
            'resize_keyboard'=>true,
            'one_time_keyboard'=>true
        ])
    ]);
}
if ($text == t('cancel_order')){
    cancelOrder($from_id);
    bot('sendMessage',[
        'text'=>"Bekor qilindi!",
        'chat_id'=>$chat_id,
        'parse_mode'=>"HTML",
        'reply_markup'=>json_encode([
            'keyboard'=>[
                [['text'=>t('home')]]
            ],
            'resize_keyboard'=>true,
            'one_time_keyboard'=>true
        ])
    ]);
}
if ($location){
    $order = getOrderStatus($chat_id);
    setOrderLocation($from_id,$location);
    verifyOrder($chat_id,$from_id);
}

if ($contact){
    $order = getOrderStatus($chat_id);
    if ($order['status'] == 1){
        setOrderPhone($chat_id,$contact->phone_number);
        requestGeo($chat_id);
    }
}

if ($text != "")
{
    $order = getOrderStatus($chat_id);
    if ($order){
        if ($order['status'] == 0){
            setOrderName($chat_id,$text);
            requestContact($chat_id);
        }elseif($order['status'] == 1){
            setOrderPhone($chat_id,$text);
            requestGeo($chat_id);
        }
    }

//    $cdata = "";
}
if ($text == t('skip')){
    $order = getOrderStatus($chat_id);
    setOrderStatus($from_id,3);
    verifyOrder($chat_id,$from_id);
}
if ($cdata == "order"){
    answerCallback();
    $order = getOrderStatus($cchat_id);
    if ($order == null){
        createOrder($cchat_id);
        requestName($cchat_id);
    }
    else{
        if ($order['status'] == 0){
            requestName($cchat_id);
        }elseif($order['status'] == 1){
            requestContact($cchat_id);
        }elseif ($order['status'] == 2){
            requestGeo($cchat_id);
        }elseif ($order['status'] == 3){
            verifyOrder($cchat_id,$cfrom_id,$cqid);
        }
    }

}


if ($cdata[0] == 'c') {

    $cname = substr($cdata, 1);

    if (empty(haveChilds(getCategoryId($cname)))) {
//        $callback_message = unserialize(file_get_contents('callback.bin'));
//        deleteMessage($callback_message->result->chat->id,$callback_message->result->message_id);
        sendProducts($cchat_id, $cname);
//        bot('sendMessage',[
//            'text'=>"Bo'sh",
//            'chat_id'=>$cchat_id
//        ]);
    } else {

        sendChildCategories($cchat_id, $cname);

    }
    bot('answerCallbackQuery', [
        'callback_query_id' => $cqid
    ]);

}
if ($cdata == "lagan"){
    $cart = getCartInfo($cfrom_id);
    if (empty($cart)){
        answerCallback();
        bot('sendMessage',[
            'text'=>t('emptycart'),
            'chat_id'=>$cchat_id
        ]);
        home($cchat_id);
        return;
    }
    $cartHtml =  t('savatdagimah').":".PHP_EOL.PHP_EOL;
    $sum = 0;
    foreach ($cart as $product) {
        $sum += $product->product_price * $product->qty;
        $cartHtml.= "✅".getProductNameById($product->product_id)." ".$product->qty."x ".$product->product_price." = ".$product->qty*$product->product_price." сўм".PHP_EOL;
    }
    $cartHtml .= PHP_EOL.t('jami')." = ".$sum." сўм".PHP_EOL;
    bot('answerCallbackQuery', [
        'callback_query_id' => $cqid,
    ]);
    bot('sendMessage',[
       'chat_id'=>$cchat_id,
        'text' => $cartHtml,
       'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
           'inline_keyboard'=>[
               [['text'=>t('order'),'callback_data'=>"order"]],
               [['text'=>t('cancel'),'callback_data'=>"bekor"]],
               [['text'=>t('home'),'callback_data'=>"home"]]
           ]
       ])
    ]);
}
if ($cdata == 'home'){
    home($cchat_id);
}
if ($cdata == 'bekor'){
    answerCallback();
    cancelOrder($cfrom_id);
    bot('sendMessage',[
       'text'=>"Bekor qilindi!",
       'chat_id'=>$cchat_id
    ]);
    home($cchat_id);
}
if ($cdata[0] == 's') {

    $data = json_decode(substr($cdata,1));

    addProductToCart($cfrom_id,$data->product_id,$data->product_price,$data->count);

    bot('answerCallbackQuery', [
        'callback_query_id' => $cqid,
        'text' => "Muvaffaqiyatli!".PHP_EOL.$data->count." dona savatga qo'shildi!",
        'show_alert' => true
    ]);


}
if ($text == "/start") {
    home($chat_id);
}
