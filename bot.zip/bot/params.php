<?php

return [
    'botToken'=>"1139341674:AAHzUZtuUM5LkwydYR62p_jNy0uR4AfhJmY",
    'webhookUrl'=>"https://itmasters.uz/bot/bot.php",

    'user_key'=>"ck_6a6bab0178b80d2a01c6aa912766c2e87ebfe0f5",
    'secret'=>"cs_c8f49776cb59fb005a82e2dd0e1c2fc47517f177",

    'admin_id'=>1203397134,

    'db'=>[
        'name'=>"u0981321_simsimbot",
        'user'=>"u0981321_simsimbot",
        'password'=>"Sef%?B5wLjqX"
    ]

];
