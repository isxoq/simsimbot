<?php
$params = require ('./params.php');
require ('./database.php');
require ("functions.php");


$words=[
    'uz'=>"O'zbekcha",
    'ru'=>"Русский"
];


define('API_KEY',$params['botToken']);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $update->message->text;
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
//$panel = file_get_contents("panel.txt");
$name = $message->from->first_name;
$lastname = $message->from->last_name;
$username = $message->from->username;
$from_id = $message->from->id;

//$user1 = new User();
//echo (createUser(45));
//echo $user1->test();
//
//echo ("<pre>");
//echo is_registered(1203397134);
//echo ("</pre>");

//TIL ni tanlash
function selectLanguage(){
    global $chat_id;
    global $words;
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=> "Xush kelibsiz! Avval ro'yhatdan o'ting!",
        'parse_mode'=>"HTML",
        'reply_markup'=>json_encode([
            'keyboard'=>[
                [['text'=>$words['uz']],['text'=>$words['ru']]],
            ],
            'resize_keyboard'=>true,
        ])
    ]);
}




if (($text == $words['uz']) || ($text == $words['ru'])){
    if ($text == $words['uz']){
        $lang = "uz";
    }else{
        $lang = "ru";
    }
    if (is_registered($from_id) == 0){
        createUser([
            'from_id'=>$from_id,
            'language'=>$lang
        ]);
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"Telefon raqamingizni yuboring:"
        ]);
    }else{
        updateUserLanguage($from_id,$lang);
    }

}



if ($text == "/start"){
    if (is_registered($from_id) == false){
        selectLanguage();
    }

}

$conn->close();
?>