<?php
// Create connection
$conn = new mysqli('localhost', $params['db']['user'], $params['db']['password'],$params['db']['name']);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>