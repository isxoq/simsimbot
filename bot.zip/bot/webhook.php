<?php
$params = require ('./params.php');

$webhookUrl = $params['webhookUrl'];
$botToken = $params['botToken'];

$url = "https://api.telegram.org/bot".$botToken."/setWebhook?url=".$webhookUrl;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$res = curl_exec($ch);
if(curl_error($ch)){
    var_dump(curl_error($ch));
}else{
    print_r(json_decode($res));
}
