<?php

function test(){
    return "test";
}

function is_registered($id)
{
    global $conn;
    $result = $conn->query("select * from user where telegram_id = '{$id}'");

    $conn->close();

    if ($result->num_rows > 0) {
        // output data of each row
        $conn->close();
        return 1;
    }else{
        $conn->close();
        return 0;
    }


}
function createUser($telegram_user_id){
    global $conn;
    $sql = "insert into user(telegram_id) values ({$telegram_user_id})";
    if ($conn->query($sql) === TRUE) {
        $conn->close();
        return "New record created successfully";
    } else {
        $conn->close();
        return "Error: " . $sql . "<br>" . $conn->error;
    }
}





