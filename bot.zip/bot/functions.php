<?php
//$params = require ('./params.php');
//require ('./database.php');
require __DIR__ . '/vendor/autoload.php';

use Automattic\WooCommerce\Client;

$woocommerce = new Client(
    'http://simsimbazar.uz/',
    'ck_6a6bab0178b80d2a01c6aa912766c2e87ebfe0f5',
    'cs_c8f49776cb59fb005a82e2dd0e1c2fc47517f177',
    [
        'version' => 'wc/v3',
    ]
);
define('ORDER_PREPARING',1);
define('ORDERED',2);

function debug($d)
{
    echo("<pre>");
    print_r($d);
    echo("</pre>");
}

function t($word)
{
    $dict = [
        'home' => "🏠Bosh sahifa",
        'cancel_order'=>"❌Bekor qilish",
        'cart'=>"🛒Savatcha",
        'emptycart'=>"📪Sizning savatingiz bo'sh!",
        'savatcha'=>"🛒Savatcha",
        'savatdagimah'=>"🍦Savatdagi mahsulotlar🔰",
        'order'=>"✳Buyurtma berish",
        'cancel'=>"❌Bekor qilish",
        'request_ism'=>"Ⓜ Ismingizni kiriting: ",
        'request_contact_text'=>"🔢 Telefon raqamingizni yuboring yoki 📲Yuborish tugmasini bosing: ",
        'request_contact_button'=>"📲Yuborish",
        'request_geo_text'=>"🚩Geolokatsiyangizni yuboring: ",
        'request_geo_button'=>"🚩Yuborish",
        'request_contact_button'=>"📲Yuborish",
        'skip'=>"⏭O'tkazib yuborish",
        'verify'=>"✅Tasdiqlayman, buyurtma berish✅",
        'process_save'=>"⌛Kuting...",
        'order_accepted'=>"ℹBuyurtmangiz jo'natildi, xizmatlarimizdan foydalanganingiz uchun tashakkur!",
        'jami'=>"💶Jami: ",
        'sonnitanlang'=>"👜Mahsulotni savatga qo'shish uchun kerakli sonni tanlang👇",
        "make_order"=>"🖨Buyurtmani rasmiylashtirish",
        'ism'=>"ⓂIsm: ",
        'user'=>"🙎‍♂️Buyurtmachi:",
        'telefon'=>"📞Telefon: ",
        'new_order'=>"🆕Sizga buyurtma keldi"

    ];
    if ($dict[$word]) {
        return $dict[$word];
    } else {
        return $word;
    }
}


function is_registered($id)
{
    global $conn;
    $result = $conn->query("select * from user where telegram_id = '{$id}'");


    if ($result->num_rows > 0) {
        // output data of each row

        return 1;
    } else {

        return 0;
    }


}

function addProductToCart($user_id, $product_id,$product_price, $qty)
{
    global $conn;
    $sql = "select * from cart where user_id={$user_id} and product_id={$product_id}";
    $r = $conn->query($sql);
    if ($r->num_rows > 0) {
        $sql = "update  cart set qty = qty + {$qty} where product_id = {$product_id}";
        $conn->query($sql);

    } else {
        $sql = "insert into cart values ('',{$user_id},{$product_id},{$product_price},{$qty})";
        $conn->query($sql);
    }




}

function requestName($chat_id){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>t('request_ism')
    ]);
}
function requestContact($chat_id){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'parse_mode'=>"HTML",
        'text'=>t('request_contact_text'),
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => t('request_contact_button'), 'request_contact' => true]]
            ],

            'resize_keyboard' => true,
            'one_time_keyboard'=>true
        ])
    ]);
}
function getOrderByUserId($user_id){
    global $conn;
    $sql = "select * from wo_order where user_id={$user_id}";

    $r = $conn->query($sql);
    if ($r->num_rows > 0){
        return $r->fetch_assoc();
    }else{
        return 0;
    }
}
function verifyOrder($cchat_id,$cfrom_id){
    $order = getOrderByUserId($cfrom_id);
    $cart = getCartInfo($cfrom_id);

    $cartHtml =  t('make_order').":".PHP_EOL.PHP_EOL;
    $sum = 0;
    foreach ($cart as $product) {
        $sum += $product->product_price * $product->qty;
        $cartHtml.= "✅".getProductNameById($product->product_id)." ".$product->qty."x ".$product->product_price." = ".$product->qty*$product->product_price.PHP_EOL;
    }
    $cartHtml .= PHP_EOL."----------------".PHP_EOL;

    $cartHtml .= PHP_EOL.t('jami')." = ".$sum.PHP_EOL;

    $cartHtml .= PHP_EOL.t('user').PHP_EOL;

    $cartHtml .= PHP_EOL.t('ism').$order['name'].PHP_EOL;

    $cartHtml .= t('telefon')." ".$order['phone'].PHP_EOL;

    bot('sendMessage',[
        'chat_id'=>$cchat_id,
        'text' => $cartHtml,
        'parse_mode'=>"HTML",
        'reply_markup'=>json_encode([
            'keyboard'=>[
                [['text'=>t('verify')]],
                [['text'=>t('cancel_order')]],
            ],
            'resize_keyboard'=>true
        ])
    ]);
}
function sendNotification($cchat_id,$cfrom_id,$to){
    $order = getOrderByUserId($cfrom_id);
    $cart = getCartInfo($cfrom_id);

    $cartHtml =  t('new_order').":".PHP_EOL.PHP_EOL;
    $sum = 0;
    foreach ($cart as $product) {
        $sum += $product->product_price * $product->qty;
        $cartHtml.= "✅".getProductNameById($product->product_id)." ".$product->qty."x ".$product->product_price." = ".$product->qty*$product->product_price.PHP_EOL;
    }
    $cartHtml .= PHP_EOL."----------------".PHP_EOL;

    $cartHtml .= PHP_EOL.t('jami')." = ".$sum.PHP_EOL;

    $cartHtml .= PHP_EOL.t('user').PHP_EOL;

    $cartHtml .= PHP_EOL.t('ism').$order['name'].PHP_EOL;

    $cartHtml .= t('telefon')." ".$order['phone'].PHP_EOL;

    bot('sendMessage',[
        'chat_id'=>$to,
        'text' => $cartHtml,
    ]);
    if ($order['coor_lat']){
        bot('sendLocation',[
            'chat_id'=>$to,
            'latitude'=>$order['coor_lat'],
            'longitude'=>$order['coor_long']
        ]);
    }
}
function requestGeo($chat_id){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'parse_mode'=>"HTML",
        'text'=>t('request_geo_text'),
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => t('request_geo_button'), 'request_location' => true]],
                [['text' => t('skip'),]]
            ],

            'resize_keyboard' => true,
            'one_time_keyboard'=>true
        ])
    ]);
}

function updateUserLanguage($from_id, $lang){
    global $conn;
    $sql = "update user set lang = '{$lang}' where telegram_id = {$from_id}";
    if ($conn->query($sql) === TRUE) {

        return "New record created successfully";
    } else {

        return json_encode($conn->error);
    }
}

function getCartInfo($user_id){
    global $conn;
    $sql = "select * from cart where user_id={$user_id}";

    $r = $conn->query($sql);
    if ($r->num_rows > 0){
        $rows = [];
        while($row = $r->fetch_object()) {
            $rows[] = $row;
        }
        return $rows;
    }else{
        return 0;
    }

}

function setOrderPhone($user_id,$phone){
    global $conn;
    $sql = "update wo_order set phone='{$phone}' where user_id = {$user_id}";
    if ($conn->query($sql) === TRUE){
        $sql = "update wo_order set status=2 where user_id = {$user_id}";
        if ($conn->query($sql) === TRUE){
            return true;
        }else{
            return $conn->error;
        }
    }else{
        return false;
    }
}
function setOrderStatus($user_id,$status){
    global $conn;
    $sql = "update wo_order set status={$status} where user_id = {$user_id}";
    if ($conn->query($sql) === TRUE){
        return true;
    }else{
        return $conn->error;
    }
}
function setOrderLocation($user_id,$location){
    global $conn;
    $sql = "update wo_order set coor_lat={$location->latitude}, coor_long={$location->longitude} where user_id = {$user_id}";
    if ($conn->query($sql) === TRUE){
        $sql = "update wo_order set status=3 where user_id = {$user_id}";
        if ($conn->query($sql) === TRUE){
            return true;
        }else{
            return $conn->error;
        }
    }else{
        return false;
    }
}
function setOrderName($user_id,$name){
    global $conn;
    $sql = "update wo_order set name='{$name}' where user_id = {$user_id}";
    if ($conn->query($sql) === TRUE){
        $sql = "update wo_order set status=1 where user_id = {$user_id}";
        if ($conn->query($sql) === TRUE){
            return true;
        }else{
            return $conn->error;
        }
    }else{
        return $conn->error;
    }
}
function changeOrderStatus($user_id,$status){
    global $conn;
    $sql = "update wo_order set status={$status} where user_id = {$user_id}";
    if ($conn->query($sql) === TRUE){
        return true;
    }else{
        return false;
    }
}
function getOrderStatus($user_id){

    global $conn;
    $sql = "select * from wo_order where user_id={$user_id}";
    $result = $conn->query($sql);
    if ($result->num_rows > 0){
        return $result->fetch_assoc();
    }

}

function createOrder($user_id){
    global $conn;
    $sql = "insert into wo_order (user_id) values({$user_id})";
    if ($conn->query($sql) === TRUE){
        return true;
    }else{
        return $conn->error;
    }
}
function cancelOrder($user_id){
    global $conn;
    $sql = "delete from cart where user_id = {$user_id}";
    if ($conn->query($sql) === TRUE){
        $sql = "delete from wo_order where user_id = {$user_id}";
        if ($conn->query($sql) === TRUE){
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
}
function createUser($info)
{
    global $conn;
    $sql = "insert into user(telegram_id,lang) values ({$info['from_id']},'{$info['language']}')";
    if ($conn->query($sql) === TRUE) {

        return "New record created successfully";
    } else {

        return json_encode($conn->error);
    }
}
function getProductNameById($id){
    $products = getProducts();
    foreach ($products as $product) {
        if ($id == $product->id){
            return $product->name;
        }
    }
}


function getPhone($from_id)
{
    global $conn;
    $result = $conn->query("select phone from user where telegram_id = '{$from_id}'");

    return $result->fetch_assoc()['phone'];
}

function sendChildCategories($chat_id, $category_name)
{
//    return getMenuCategories(haveChilds(getCategoryId("Grocery")));
    $keyboard = getMenuCategories(haveChilds(getCategoryId($category_name)));
//    $callback_message = unserialize(file_get_contents('callback.bin'));
//    deleteMessage($callback_message->result->chat->id,$callback_message->result->message_id);

    $res = bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $category_name,
        'parse_mode' => "HTML",
        'reply_markup' => json_encode([
            'inline_keyboard' => $keyboard,
//                [['text'=>"salom1"]],[['text'=>"salom1"]]

            'resize_keyboard' => true,
        ])
    ]);
    file_put_contents('callback.bin', json_encode($res));
}


function getCategories()
{

    $categoriesData = json_decode(file_get_contents("categories.bin"));

    return $categoriesData;
}

function getMainCategories()
{
    $categories = [];
    $categoriesData = json_decode(file_get_contents("categories.bin"));
    foreach ($categoriesData as $c) {
        if ($c->parent == 0) {
            $categories[] = $c;
        }
    }
    return $categories;
}

function getCategoriesById($category_id)
{
    $categories = [];
    $categoriesData = json_decode(file_get_contents("categories.bin"));
    foreach ($categoriesData as $c) {
        if ($c->parent == $category_id) {
            $categories[] = $c;
        }
    }
    return $categories;
}

function haveChilds($cat_id)
{
    $cats = getCategoriesById($cat_id);
    $childs = [];
    foreach ($cats as $cat) {
        if ($cat->parent == $cat_id) {
            $childs[] = $cat;
        }
    }
    return $cats;
}

function getCategoryId($name)
{
    $cats = getCategories();
    foreach ($cats as $cat) {
        if ($cat->name == $name) {
            return $cat->id;
        }
    }
    return null;
}

function getMenuCategories($cats)
{
    $menu = [];
    $soni = count($cats);

    if ($soni % 2 == 1) {
        $menu[] = [['text' => $cats[0]->name, 'callback_data' => "c" . $cats[0]->name]];
        for ($i = 1; $i < $soni; $i = $i + 2) {
            $menu[] = [['text' => $cats[$i]->name, 'callback_data' => "c" . $cats[$i]->name], ['text' => $cats[$i + 1]->name, 'callback_data' => "c" . $cats[$i + 1]->name]];
        }
    } else {
        for ($i = 0; $i < $soni; $i = $i + 2) {
            $menu[] = [['text' => $cats[$i]->name, 'callback_data' => "c" . $cats[$i]->name], ['text' => $cats[$i + 1]->name, 'callback_data' => "c" . $cats[$i + 1]->name]];
        }
    }
    $menu[] = [['text'=>t('cart'),'callback_data'=>t('lagan')]];
    return $menu;
}

function getProducts()
{
    $products = json_decode(file_get_contents('products.bin'));
    return $products;
}

function getProductById($id)
{
    foreach (getProducts() as $product) {
        if ($product->id == $id) {
            return $product;
        }
    }
}

function getProductByCategoryId($id)
{
    $products = [];
    foreach (getProducts() as $product) {
        if ($product->categories[0]->id == $id) {
            $products[] = $product;
        }
    }
    return $products;
}

function sendProducts($chat_id, $cname)
{
    $category_id = getCategoryId($cname);
//    bot('sendMessage',[
//        'chat_id'=>$chat_id,
//        'text'=>$category_id
//    ]);
    foreach (getProductByCategoryId($category_id) as $product) {
        if ($product->sale_price) {
            $caption = '<b>' . $product->name . '</b>' . PHP_EOL . t('narxi') . ': ' . '<strike>' . $product->regular_price . '</strike>' . ' сўм' . PHP_EOL . t('chegirmalinarxi') . ": " . $product->price . ' сўм' . PHP_EOL . t('sonnitanlang');
        } else {
            $caption = '<b>' . $product->name . '</b>' . PHP_EOL . t('narxi') . ': ' . $product->price . " сўм" .PHP_EOL.PHP_EOL. t('sonnitanlang');

        }

        bot('sendPhoto', [
            'chat_id' => $chat_id,
            'parse_mode' => "HTML",
            'caption' => $caption,
            'photo' => $product->images[0]->src,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "1", 'callback_data' => 's' . json_encode(['count' => 1, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "2", 'callback_data' => 's' . json_encode(['count' => 2, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "3", 'callback_data' => 's' . json_encode(['count' => 3, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "4", 'callback_data' => 's' . json_encode(['count' => 4, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "5", 'callback_data' => 's' . json_encode(['count' => 5, 'product_id' => $product->id,'product_price'=>$product->price])],
                    ],
                    [
                        ['text' => "10", 'callback_data' => 's' . json_encode(['count' => 10, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "20", 'callback_data' => 's' . json_encode(['count' => 20, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "30", 'callback_data' => 's' . json_encode(['count' => 30, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "40", 'callback_data' => 's' . json_encode(['count' => 40, 'product_id' => $product->id,'product_price'=>$product->price])],
                        ['text' => "50", 'callback_data' => 's' . json_encode(['count' => 50, 'product_id' => $product->id,'product_price'=>$product->price])],
                    ],
                    [
                        ['text' => t('savatcha'), 'callback_data' => "lagan"]
                    ]
                ],

                'resize_keyboard' => true,
            ])
        ]);
    }
}

function deleteMessage($chat_id, $message_id)
{

    bot('deleteMessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id
    ]);
}

function home($chat_id)
{

    $res = bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => t('home'),
        'parse_mode' => "HTML",
        'reply_markup' => json_encode([
            'inline_keyboard' => getMenuCategories(getMainCategories()),

//                [['text'=>"salom1"]],[['text'=>"salom1"]]
//            'keyboard'=>[[['text'=>'dsda']]],
            'resize_keyboard' => true,
        ])
    ]);
    file_put_contents('callback.bin', json_encode($res));
}
function saveOrder($user_id){
    global $woocommerce;
    $order = getOrderStatus($user_id);

    $products = [];
    foreach (getCartInfo($user_id) as $product){
        $products[] = ['product_id'=>$product->product_id,'quantity'=>$product->qty];
    }
    $data = [
        'payment_method' => 'bacs',
        'payment_method_title' => 'Direct Bank Transfer',
        'set_paid' => true,
        'billing' => [
            'first_name' => $order['name'],
            'phone' => $order['phone']
        ],
        'line_items' => $products,
    ];
    $woocommerce->post('orders', $data);
}

//debug(getMenuCategories(haveChilds(getCategoryId("Grocery"))));
//debug(getMenuCategories(getCategories()));
//debug(sendChildCategories("Grocery"));
//debug(getCategories());
//debug(getProducts());
//debug(getProductById(1003));
//debug(getProductByCategoryId(40));
//debug($woocommerce->get('products'));
