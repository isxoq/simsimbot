<?php
require __DIR__ . '/vendor/autoload.php';

use Automattic\WooCommerce\Client;

$woocommerce = new Client(
    'http://simsimbazar.uz/',
    'ck_6a6bab0178b80d2a01c6aa912766c2e87ebfe0f5',
    'cs_c8f49776cb59fb005a82e2dd0e1c2fc47517f177',
    [
        'version' => 'wc/v3',
    ]
);

$categories = $woocommerce->get('products/categories');
$products = $woocommerce->get('products');
file_put_contents("categories.bin",json_encode($categories));
file_put_contents("products.bin",json_encode($products));